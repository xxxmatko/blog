(function(baseUrl) {
	baseUrl.endsWith("/") && (baseUrl = baseUrl.replace(/\/+$/g, ""));
	
	require({
		paths: {
			"app": baseUrl + "/app"
		},
		config: {
			"app": {
			}
		}
	}, ["app"]);
})(location.pathname.replace(/\/[^/]+$/, ""));

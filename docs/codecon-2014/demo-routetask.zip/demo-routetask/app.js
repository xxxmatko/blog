define([
    // Esri modules
	"esri/map",
    "esri/tasks/locator",
    "esri/tasks/RouteTask", 
    "esri/tasks/RouteParameters",
    "esri/tasks/FeatureSet",
    "esri/graphic",
    "esri/symbols/SimpleLineSymbol", 
    // Dojo modules
    "dojo/dom",
    "dojo/on",
    "dojo/promise/all",
    "dojo/_base/array",
    "dojo/domReady!"
], function (Map, Locator, RouteTask, RouteParameters, FeatureSet, Graphic, SimpleLineSymbol, dom, on, all, array) {
    // Vytvorime instanciu Mapy
	var map = window.map = new Map("map", {
	  basemap: "streets",
	  center: [17.1193, 48.1610],
	  zoom: 13
	});

        // Napojenie event handler-ov
	on(dom.byId("btnGetRoute"), "click", _btnGetRoute_onClick);

    // Vytvorime geocoding locator service pre najdenie zaciatocnej a koncovej adresy
	var locator = new Locator("http://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer");
	locator.outSpatialReference = map.spatialReference;

    /**
     * Spracovanie udalosti kliknutia na tlaciko 'btnGetRoute'.
     */
	function _btnGetRoute_onClick(e) {
	    // Zistime zaciatocnu adresu
        var start = locator.addressToLocations({
            address: {
                "SingleLine": dom.byId("tbStart").value
            }
        });

	    // Zistime cielovu adresu
        var end = locator.addressToLocations({
            address: {
                "SingleLine": dom.byId("tbEnd").value
            }
        });

        // Vypocet cesty sa spusti az ked sa nasla zaciatocna a aj cielova adresa
        all({
            startAddress: start,
            endAddress: end
        }).then(findRoute);
	}

    /**
     * Najdenie cesty medzi dvoma adresami.
     */
	function findRoute(results) {
	    var start = getAddress(results.startAddress);
	    var end = getAddress(results.endAddress);
	    
        // Vytvorime symbol pre zaciatok a koniec cesty
	    var markerSymbol = {
	        color: [255, 0, 0],
	        size: 8,
	        type: "esriSMS",
	        style: "esriSMSX",
	        outline: {
	            color: [255, 0, 0],
	            width: 3,
	            type: "esriSLS",
	            style: "esriSLSSolid"
	        }
	    }

        // Vytvorime parametre pre task
	    var params = new RouteParameters();
	    params.returnRoutes = true;
	    params.returnDirections = false;
	    params.directionsLengthUnits = "esriMiles";
	    params.outSpatialReference = map.spatialReference;

	    params.stops = new FeatureSet();
	    params.stops.features.push(
            map.graphics.add(
                new Graphic({
                    geometry: start.location,
                    symbol: markerSymbol
                })
            )
        );
	    params.stops.features.push(
            map.graphics.add(
                new Graphic({
                    geometry: end.location,
                    symbol: markerSymbol
                })
            )
        );

		// TODO: Pre zaregistrovanie aplikacie a ziskanie tokenu postupovat podla navodu:
		// http://blog.aspnet.sk/xxxmatko/archive/2014/09/17/ako-pristupova-k-zabezpe-en-253-m-esri-arcgis-slu-b-225-m.aspx
        // Vytvorime route task
	    var task = new RouteTask("http://route.arcgis.com/arcgis/rest/services/World/Route/NAServer/Route_World/?token=<TOKEN>");
	    task.solve(params,
	        function (results) {
	            var route = results.routeResults[0].route;
	            
	            route.setSymbol(new SimpleLineSymbol({ 
	                color: [0, 0, 255, 128], 
	                width: 3.75, 
	                type: "esriSLS", 
	                style: "esriSLSSolid"
	            }));

	            map.graphics.add(route);
	        },
	        function (err) {
	            console.warn(err.message);
	            err.details && console.warn(err.details[0]);
	        }
	    );
	}

    /**
     * Najde adresu s najvyssim skore.
     */
    function getAddress(candidates) {
        var address = null;
        var score = 0;

        array.forEach(candidates, function (candidate) {
            if (candidate.score <= score) {
                return;
            }
            
            address = candidate;
            score = candidate.score;
        });

        return address;
    }
});
